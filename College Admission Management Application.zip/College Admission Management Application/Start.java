import java.lang.*;
import classes.Employee;
import classes.Student;
import classes.*;
import java.util.Scanner;
import fileio.FileReadWriteDemo;

public class Start
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		FileReadWriteDemo frwd = new FileReadWriteDemo();
        Science sss = new Science();
        Humanities sss1 = new Humanities();
        BusinessStudies sss2 = new BusinessStudies();
		String n, bn;
		System.out.print("Enter College Name : ");
		n = sc.next();
		System.out.print("Enter Branch Name  : ");
		bn = sc.next();
		College cc = new College(n, bn);
		
		
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		System.out.println("$$$$   Welcome to "+cc.getName()+" ("+cc.getBranchName()+")  Admission  Application  $$$$");
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		
		boolean repeat = true;
		
		while(repeat)
		{
			System.out.println();
			System.out.println("\tWhat Do You Want To Do?\n");
			System.out.println("\t\t1. Account Management");
			System.out.println("\t\t2. Employee Management");
			System.out.println("\t\t3. Student Management");
			System.out.println("\t\t4. Seat Management");
			System.out.println("\t\t5. Show College Information");
			System.out.println("\t\t6. Exit");
		
			System.out.println("\n---------------------------");
			System.out.print("Enter Your Choice: ");
			int choice = sc.nextInt();
			System.out.println("---------------------------\n");
			
			
			switch(choice)
			{
			  case 1:
                        System.out.println("#####################################");
                        System.out.println("You Have Selected Account Management");
                        System.out.println("#####################################");
                        System.out.println();
                    
                        boolean repeat2 = true;
                            
                        while(repeat2)
                       {
                    
                            System.out.println("\tAccount Management Options are: \n");
                            System.out.println("\t\t1. Insert New Account");
                            System.out.println("\t\t2. Remove Account");
                            System.out.println("\t\t3. Search Account");
                            System.out.println("\t\t4. Show All Accounts");
                            System.out.println("\t\t5. Go Back");
                            
                            System.out.println("\n---------------------------");
                            System.out.print("Enter Your Option: ");
                            int option2 = sc.nextInt();
                            System.out.println("---------------------------\n");
                            
                            switch(option2)

                               { 
                                    case 1:
                                        
                                        System.out.println("*********************************");
                                        System.out.println("You Have Selected Insert Account");
                                        System.out.println("*********************************");
                                        System.out.println();
                                        
                                        System.out.print("Enter Account Name   : ");
                                        String anm1 = sc.next();
                                        System.out.print("Enter NID            : ");
                                        String anid1 = sc.next();
                                        System.out.print("Enter Gender         : ");
                                        String age1 = sc.next();
                                        System.out.print("Enter Phone Number   : ");
                                        String aph1 = sc.next();
                                        System.out.print("Enter Admission Date : ");
                                        String aad1 = sc.next();
                                        
                                        Account a1 = new Account(anm1,anid1,age1,aph1,aad1);
                                        
                                        
                                        if(cc.insertAccount(a1))
                                        {
                                            System.out.println(anid1 + " Account Has Been Inserted");
                                        }
                                        else
                                        {
                                            System.out.println(anid1+ " Account Can NOT be Inserted");
                                        }
                                       
                                        break;
                                        
                                    case 2:
                                        
                                        System.out.println("*********************************");
                                        System.out.println("You Have Selected Remove Account");
                                        System.out.println("*********************************");
                                        System.out.println();
                                        
                                        System.out.print("Enter The NID to remove a Account: ");
                                        String anid2 = sc.next();
                                        
                                        Account a2 = cc.searchAccount(anid2);
                                        
                                        if(a2 != null)
                                        {
                                            if(cc.removeAccount(a2))
                                            {
                                                System.out.println(anid2+"*** Account Removed ***");
                                            }
                                        }
                                        else
                                        {
                                            System.out.println( anid2 +"*** Account Can NOT be Removed ***");
                                        }
                                        
                                        break;
                                        
                                    case 3:
                                    
                                        System.out.println("*********************************");
                                        System.out.println("You Have Selected Search Account");
                                        System.out.println("*********************************");
                                        System.out.println();
                                        
                                        System.out.print("Enter The NID to search a Account: ");
                                        String anid3 = sc.next();
                                        
                                        Account a3 = cc.searchAccount(anid3);
                                        
                                        if(a3 != null)
                                        {
                                            System.out.println("*** Account Found ***");
                                            a3.showDetails();
                                        }
                                        else
                                        {
                                            System.out.println("*** Account NOT Found ***");
                                        }
                                        
                                        break;
                                        
                                    case 4:
                                        
                                        System.out.println("************************************");
                                        System.out.println("You Have Selected Show All Accounts");
                                        System.out.println("************************************");
                                        System.out.println();
                                        
                                        cc.showAllAccounts();
                                        
                                        break;
                                        
                                    case 5:
                                        
                                        System.out.println("*********************");
                                        System.out.println("Going Back...........");
                                        System.out.println("*********************");
                                        repeat2 = false;
                                        System.out.println();

                                        break;
                                        
                                    default:
                                        
                                        System.out.println("*********************");
                                        System.out.println("Invalid Option.......");
                                        System.out.println("*********************");
                                        System.out.println();
                                        repeat2 = false;

                                        break;
                                        
                                
                          
                                }
                        }
            
                      break;
              case 2:
                        System.out.println("#####################################");
                        System.out.println("You Have Selected Employee Management");
                        System.out.println("#####################################");
                        System.out.println();
                        
                        boolean repeat1 = true;
                        
                        while(repeat1)
                        {
                        
                            System.out.println("\tEmployee Management Options are: \n");
                            System.out.println("\t\t1. Insert New Employee");
                            System.out.println("\t\t2. Remove Employee");
                            System.out.println("\t\t3. Search Employee");
                            System.out.println("\t\t4. Show All Employees");
                            System.out.println("\t\t5. Go Back");
                            
                            System.out.println("\n---------------------------");
                            System.out.print("Enter Your Option  : ");
                            int option1 = sc.nextInt();
                            System.out.println("---------------------------\n");
                            
                            switch(option1)
                            {
                                case 1:
                                    
                                        System.out.println("*********************************");
                                        System.out.println("You Have Selected Insert Employee");
                                        System.out.println("*********************************");
                                        System.out.println();

                                        System.out.print("Enter Account NID for Verification: ");
                                        String nid1 = sc.next();
                                        
                                        Account c1 = cc.searchAccount(nid1);
                                        
                                        if(c1 != null)
                                        {
                                            System.out.println("**** Valid Account ****");
                                                
                                            
                                                System.out.print("Enter Employee ID     : ");
                                                String eid1 = sc.next();
                                                
                                                System.out.print("Enter Employee salary : ");
                                                double esa1 = sc.nextDouble();
                                            
                                                Employee e1 = new Employee(eid1,c1,esa1);
                                            
                                            
                                                if(cc.insertEmployee(e1))
                                                {
                                                System.out.println(eid1 + " Employee Has Been Inserted");
                                                }
                                                else
                                                {
                                                System.out.println(eid1 + " Employee Can NOT be Inserted");
                                                }
                                    
                                        
                                            
                                        }
                                        else
                                        {
                                            System.out.println("**** Invalid Account ****");
                                        }
                                        break;
                                    
                               case 2:
                                        
                                        System.out.println("*********************************");
                                        System.out.println("You Have Selected Remove Employee");
                                        System.out.println("*********************************");
                                        System.out.println();

                                    
                                        System.out.print("Enter The Employee ID to remove a Employee : ");
                                        String eid2 = sc.next();
                                        
                                       
                                        
                                        if(cc.searchEmployee(eid2) != null)
                                        {
                                            if(cc.removeEmployee(cc.searchEmployee(eid2)))
                                            {
                                                System.out.println( eid2 +"*** Employee Removed ***");
                                            }
                                        }
                                        else
                                        {
                                            System.out.println(eid2 +"*** Employee Can NOT be Removed ***");
                                        }
                                        
                                        
                                        break;
                                        
                                case 3:
                                                
                                        System.out.println("*********************************");
                                        System.out.println("You Have Selected Search Employee");
                                        System.out.println("*********************************");
                                        System.out.println();

                                    
                                        System.out.print("Enter The Employee ID to Search a Employee : ");
                                        String eid3 = sc.next();
                                        
                                        
                                        
                                        if(cc.searchEmployee(eid3) != null)
                                        {
                                            System.out.println("*** Employee Found ***");
                                            cc.searchEmployee(eid3).showDetails();
                                        }
                                        else
                                        {
                                            System.out.println("*** Employee Not Found ***");
                                        }
                                        
                                
                                

                                        break;
                                case 4:
                                            
                                            System.out.println("************************************");
                                            System.out.println("You Have Selected Show All Employees");
                                            System.out.println("************************************");
                                            System.out.println();
                                            
                                            cc.showAllEmployees();
                                            break;
                                            
                                case 5:
                                            
                                            System.out.println("*********************");
                                            System.out.println("Going Back...........");
                                            System.out.println("*********************");
                                            repeat1 = false;
                                            System.out.println();
                                            break;
                                            
                                default:
                                            
                                            System.out.println("*********************");
                                            System.out.println("Invalid Option.......");
                                            System.out.println("*********************");
                                            System.out.println();
                                            repeat1 = false;
                                            break;
                            }
                        }
                        
                        break;
              case 3:              
                        System.out.println("#####################################");
                        System.out.println("You Have Selected Student Management");
                        System.out.println("#####################################");
                        System.out.println();
                        
                        boolean repeat3 = true;
                        
                        while(repeat3)
                        {
                                System.out.println("\tStudent Management Options are: \n");
                                System.out.println("\t\t1. Insert New Student");
                                System.out.println("\t\t2. Remove Student");
                                System.out.println("\t\t3. Search Student");
                                System.out.println("\t\t4. Show All Students");
                                System.out.println("\t\t5. Go Back");
                                
                                System.out.println("\n---------------------------");
                                System.out.print("Enter Your Option  : ");
                                int option3 = sc.nextInt();
                                System.out.println("---------------------------\n");
                                
                                switch(option3)
                                {
                                   case 1:                                  
                                            System.out.println("********************************");
                                            System.out.println("You Have Selected Insert Student");
                                            System.out.println("********************************");
                                            System.out.println();
                                            
                                            boolean repeat11 = true;
                            
                                                while(repeat11)

                                                {
                                                    System.out.println("Which Type of Student Account do you want to create?");
                                                    System.out.println("\t\t 1. Science");
                                                    System.out.println("\t\t 2. Humanities");
                                                    System.out.println("\t\t 3. Business Studies");
                                                    System.out.println("\t\t 4. Go Back");
                                                    
                                                    System.out.println("\n---------------------------");
                                                    System.out.print("Enter Your Type: ");
                                                    int option11 = sc.nextInt();
                                                    System.out.println("---------------------------\n");
                                                    
                                                    Student a = null;
                                                    
                                                   
                                                        
                                                        switch(option11)
                                                        {
                                                        case 1:
                                                                
                                                                    System.out.println("***************");
                                                                    System.out.println("   Science");
                                                                    System.out.println("***************");
                                                                    System.out.println();
                                                                    System.out.print("Enter Account NID for Verification : ");
                                                                    String nid1 = sc.next();
                                                                
                                                                    Account c1 = cc.searchAccount(nid1);
                                                                
                                                                    if(c1 != null)
                                                                    {
                                                                        System.out.println("**** Valid Account ****"); 
                                                                        System.out.print("Enter Student ID               : ");
                                                                        String an = sc.next();
                                                                        System.out.print("Enter Student roll             : ");
                                                                        int ba = sc.nextInt();
                                                                        System.out.print("Enter Student Group Name       : ");
                                                                        String ga = sc.next();
                                                                        System.out.print("Enter Student Optional Subject : ");
                                                                        String op = sc.next();
                                                                        System.out.print("Enter Student Mark In Physics  : ");
                                                                        double p1 = sc.nextDouble();
                                                                        System.out.print("Enter Student Mark In Chemisty : ");
                                                                        double mc = sc.nextDouble();
                                                                        
                                                                        
                                                                        Science sa = new Science(an, c1, ba, ga,op,p1,mc);
                                                                        
                                                                        a = sa;
                                                                    }
                                                                    else
                                                                        {
                                                                            System.out.println("**** Invalid Account ****");
                                                                        }
                                                                    break;
                                                                
                                                        case 2:
                                                        
                                                                    System.out.println("***************");
                                                                    System.out.println(" Humanities ");
                                                                    System.out.println("***************");
                                                                    System.out.println();
                                                                    System.out.print("Enter Account NID for Verification : ");
                                                                    String nid12 = sc.next();
                                                                
                                                                    Account c12 = cc.searchAccount(nid12);
                                                                
                                                                    if(c12 != null)
                                                                    {   System.out.println("**** Valid Account ****");
                                                                        System.out.print("Enter Student ID                 : ");
                                                                        String han = sc.next();
                                                                        System.out.print("Enter Student roll               : ");
                                                                        int hba = sc.nextInt();
                                                                        System.out.print("Enter Student Group Name         : ");
                                                                        String hga = sc.next();
                                                                        System.out.print("Enter Student Optional Subject   : ");
                                                                        String hop = sc.next();
                                                                        System.out.print("Enter Student Mark In Logic      : ");
                                                                        double hmp = sc.nextDouble();
                                                                        System.out.print("Enter Student Mark In Economics  : ");
                                                                        double hmc = sc.nextDouble();
                                                                        
                                                                        Humanities fa = new Humanities(han, c12, hba, hga,hop,hmp,hmc);
                                                                        
                                                                        a = fa;
                                                                    }
                                                                    else
                                                                        {
                                                                            System.out.println("**** Invalid Account ****");
                                                                        }    
                                                                    break;
                                                        case 3:
                                                                    System.out.println("***************");
                                                                    System.out.println("Business Studies");
                                                                    System.out.println("***************");
                                                                    System.out.println();
                                                                    System.out.print("Enter Account NID for Verification : ");
                                                                    String nid13 = sc.next();
                                                                
                                                                    Account c13 = cc.searchAccount(nid13);
                                                                
                                                                    if(c13 != null)
                                                                    {   System.out.println("**** Valid Account ****");
                                                                        System.out.print("Enter Student ID                   : ");
                                                                        String ban = sc.next();
                                                                        System.out.print("Enter Student roll                 : ");
                                                                        int bba = sc.nextInt();
                                                                        System.out.print("Enter Student Group Name           : ");
                                                                        String bga = sc.next();
                                                                        System.out.print("Enter Student Optional Subject     : ");
                                                                        String bop = sc.next();
                                                                        System.out.print("Enter Student Mark In Accounting   : ");
                                                                        double bmp = sc.nextDouble();
                                                                        System.out.print("Enter Student Mark In Business ORG : ");
                                                                        double bmc = sc.nextDouble();
                                                                        
                                                                        BusinessStudies bsa = new BusinessStudies(ban, c13, bba, bga,bop,bmp,bmc);
                                                                        
                                                                        a = bsa;
                                                                    }
                                                                    else
                                                                        {
                                                                            System.out.println("**** Invalid Account ****");
                                                                        }
                                                                    break;
                                                        
                                                        case 4:
                                                                    System.out.println("***************");
                                                                    System.out.println("Going Back");
                                                                    System.out.println("***************");
                                                                    System.out.println();
                                                                    repeat11 = false;

                                                                    break;
                                                            
                                                        default:
                                                                    System.out.println("***************");
                                                                    System.out.println("Invalid Type");
                                                                    System.out.println("***************");
                                                                    System.out.println();
                                                                    repeat11 = false;
                                                                    break;
                                                            
                                                        }
                                                    
                                                            if(a != null)
                                                            {
                                                            if(cc.insertStudent(a))
                                                            {
                                                                System.out.println("*** Student Inserted ***");
                                                            }
                                                            else
                                                            {
                                                                System.out.println("*** Student NOT Inserted ***");
                                                            }
                                                            }
                                                     

                                                }
                                            
                                            break;
                                            
                                   case 2:  
                                            System.out.println("********************************");
                                            System.out.println("You Have Selected Remove Student");
                                            System.out.println("********************************");
                                            System.out.println();

                                            
                                            System.out.print("Enter The Student ID to remove a Student : ");
                                            String sid2 = sc.next();
                                            
                                             
                                            
                                            if(cc.searchStudent(sid2) != null)
                                            {
                                                if(cc.removeStudent(cc.searchStudent(sid2)))
                                                {
                                                    System.out.println(sid2+" *** Student Removed ***");
                                                }
                                            }
                                            else
                                            {
                                                System.out.println( sid2 +" *** Student Can NOT be Removed ***");
                                            }
                                            
                                            break;
                                        
                                   case 3:
                                            System.out.println("********************************");
                                            System.out.println("You Have Selected Search Student");
                                            System.out.println("********************************");
                                            System.out.println();
                                            System.out.print("Enter The Student ID to search a Student : ");
                                            String sid3 = sc.next();
                                            
                                             cc.searchStudent(sid3);
                                            
                                            if(cc.searchStudent(sid3) != null)
                                            {
                                                System.out.println(sid3 +" *** Student  Found ***");
                                                cc.searchStudent(sid3).showDetails();
                                            }
                                            else
                                            {
                                                System.out.println(sid3 +" *** Student  NOT Found ***");
                                            }
                                            
                                            break;
                                        
                                            
                                   case 4: 
                                            System.out.println("***********************************");
                                            System.out.println("You Have Selected Show All Students");
                                            System.out.println("***********************************");
                                            System.out.println();
                                            
                                            cc.showAllStudents();
                                            
                                            break;
                                            
                                   case 5:
                                            System.out.println("*********************");
                                            System.out.println("Going Back...........");
                                            System.out.println("*********************");
                                            repeat3 = false;
                                            System.out.println();
                                            break;
                                            
                                   default:
                                            System.out.println("*********************");
                                            System.out.println("Invalid Option.......");
                                            System.out.println("*********************");
                                            System.out.println();
                                            repeat3 = false;
                                            break;
                             }
                        }
                            
                       break;


				case 4:
					
                        System.out.println("######################################");
                        System.out.println("You Have Selected Seat Management");
                        System.out.println("######################################");
                        System.out.println();
                        
                        boolean repeat4 = true;
                        
                        while(repeat4)
                        {
                        
						System.out.println("\tSeat Management Options are: \n");
						System.out.println("\t\t1. Seat Booking ");
						System.out.println("\t\t2. Seat Vacating ");
                        System.out.println("\t\t3. Show All Seat Booking & Vacating ");
					    System.out.println("\t\t4. Go Back");
						
						System.out.println("\n---------------------------");
						System.out.print("Enter Your Option: ");
						int option4 = sc.nextInt();
						System.out.println("---------------------------\n");

						switch(option4)
						{
							case 1:
								
								System.out.println("********************************");
								System.out.println("You Have Selected Seat Booking");
								System.out.println("********************************");
								System.out.println();

                                boolean repeat5 = true;
					
                                while(repeat5)
                                {
                                    
                                    System.out.println("Which Type of Student Seat do you want to Book?");
                                    System.out.println("\t\t 1. Science");
                                    System.out.println("\t\t 2. Humanities");
                                    System.out.println("\t\t 3. Business Studies");
                                    System.out.println("\t\t 4. Go Back");
                                    System.out.println("\n---------------------------");

                                    System.out.print("Enter Your Option: ");
                                    int option6 = sc.nextInt();
                                    System.out.println("---------------------------\n");
                                    switch(option6)
                                    {
                                            case 1:
                                                    System.out.println("***************");
                                                    System.out.println("   Science   ");
                                                    System.out.println("***************");
                                                    System.out.println();
                                                    
                                                    if(sss.getScienceSeatAmount()==0)
                                                    {
                                                        System.out.print("Set  the Seat limit in Science  : ");
                                                        int am1 = sc.nextInt();
                                                        sss.setScienceSeatAmount(am1);
                                                    }

                                                    
                                                    System.out.println("Available  seats                : " + sss.getScienceSeatAmount());
                                                    System.out.print("Enter the number of seats       : ");
                                                    int am = sc.nextInt();
                                                    if(sss.fillingSeat(am))
                                                    {
                                                        System.out.println("----- Seat Booking Successfull -----");
                                                        System.out.println("Remaining seats after booked    : " + sss.getScienceSeatAmount());
                                                        frwd.writeInFile(am + " Seat Booked in Science " );
                                                    }
                                                    else
                                                    {
                                                        System.out.println("----- Seat Booking Failed -----");
                                                    }

                                                break;
                                                    
                                            case 2:
                                                    System.out.println("***************");
                                                    System.out.println("   Humanities  ");
                                                    System.out.println("***************");
                                                    System.out.println();
                                                
                                                    if(sss1.getHumanitiesSeatAmount()==0){
                                                        System.out.print("Set  the Seat limit in Humanities  : ");
                                                        int am11 = sc.nextInt();
                                                        sss1.setHumanitiesSeatAmount(am11);
                                                    }

                                                    
                                                    System.out.println("Available  seats                   : " + sss1.getHumanitiesSeatAmount ());
                                                    System.out.print("Enter  the  number  of  seats      : ");
                                                    int am2 = sc.nextInt();
                                                    if(sss1.fillingSeat(am2))
                                                    {
                                                        System.out.println("----- Seat Booking Successfull -----");
                                                        System.out.println("Remaining seats after booked  : "+ sss1.getHumanitiesSeatAmount ());
                                                        frwd.writeInFile(am2 + " Seat Booked in Humanities " );
                                                    }
                                                    else
                                                    {
                                                        System.out.println("----- Seat Booking Failed -----");
                                                    }
                                                        
                                                        break;
                                            case 3:
                                                    System.out.println("***************");
                                                    System.out.println("Business Studies  ");
                                                    System.out.println("***************");
                                                    System.out.println();
                                                
                                                    if(sss2.getBusinessStudiesAmount()==0){
                                                        System.out.print("Set the Seat limit in Business Studies : ");
                                                        int am22 = sc.nextInt();
                                                        sss2.setBusinessStudiesAmount(am22);
                                                    }
                
                                                    
                                                    System.out.println("Available   seats                      : " + sss2.getBusinessStudiesAmount());
                                                    System.out.print("Enter   the   number   of   seats      : ");
                                                    int am3 = sc.nextInt();
                                                    if(sss2.fillingSeat(am3))
                                                    {
                                                        System.out.println("----- Seat Booking Successfull -----");
                                                        System.out.println("Remaining seats after booked  : "+ sss2.getBusinessStudiesAmount());
                                                        frwd.writeInFile(am3 + " Seat Booked in Business Studies  " );
                                                    }
                                                    else
                                                    {
                                                        System.out.println("----- Seat Booking Failed -----");
                                                    }
                                                        
                                                        break;
                                            case 4:
                                                    System.out.println("*********************");
                                                    System.out.println("Going Back...........");
                                                    System.out.println("*********************");
                                                    System.out.println();
                                                    repeat5 = false;
                                                    break;
                                        default:
                        
                                                    System.out.println("######################");
                                                    System.out.println("Invalid Selection.....");
                                                    System.out.println("######################");
                                                    System.out.println();
                                                    repeat5 = false;
                                                    break;        
                                    }
                               
                                    
                                }
								
								break;
								
						  case 2:
								
								System.out.println("********************************");
								System.out.println("You Have Selected Seat Vacating ");
								System.out.println("********************************");
								System.out.println();

                                boolean repeat7 = true;
					
                                while(repeat7)
                                {
                                
                                System.out.println("Which Type of Student Seat do you want to Vacate ?");
                                System.out.println("\t\t 1. Science");
                                System.out.println("\t\t 2. Humanities");
                                System.out.println("\t\t 3. Business Studies");
                                System.out.println("\t\t 4. Go Back");
                                System.out.println("\n---------------------------");

                                System.out.print("Enter Your Option: ");
                                int option8 = sc.nextInt();
                                System.out.println("---------------------------\n");
                                switch(option8)
                                {
                                    case 1:
                                            System.out.println("***************");
                                            System.out.println("   Science ");
                                            System.out.println("***************");
                                            System.out.println();
                                        
                                            if (sss.getScienceSeatAmount() != 0) {
                                            System.out.println("Available seats               : " + sss.getScienceSeatAmount());
                                    
                                            System.out.print("Enter the number of seats  : ");
                                                int an3 = sc.nextInt();
                                                if(sss.vacatingSeat (an3))
                                                {
                                                    System.out.println("----- Seat Vacating Successfull -----");
                                                    System.out.println("Remaining seats after Vacated  : "+ sss.getScienceSeatAmount());
                                                    frwd.writeInFile(an3 + " Seat Vacate in Science " );
                                                }
                                                else
                                                {
                                                    System.out.println("----- Seat Vacating Failed -----");
                                                }
                                            }
                                            else
                                            {
                                                System.out.println("--- Please go to Seat Booking and set the Seat limit ---");
                                            
                                            }

                                                break;
                                    
                                    case 2:
                                            System.out.println("***************");
                                            System.out.println("   Humanities  ");
                                            System.out.println("***************");
                                            System.out.println();
                            
                                            if (sss1.getHumanitiesSeatAmount() != 0) {
                                                System.out.println("Available seats               : " + sss1.getHumanitiesSeatAmount());
                                        
                                                System.out.print(" Enter the number of seats  : ");
                                                    int an4 = sc.nextInt();
                                                    if(sss1.vacatingSeat (an4))
                                                    {
                                                        System.out.println("----- Seat Vacating Successfull -----");
                                                        System.out.println("Remaining seats after Vacated  : "+ sss1.getHumanitiesSeatAmount());
                                                        frwd.writeInFile(an4 + " Seat Vacate in Humanities " );
                                                    }
                                                    else
                                                    {
                                                        System.out.println("----- Seat Vacating Failed -----");
                                                    }
                                                }
                                                else
                                                {
                                                    System.out.println("--- Please go to Seat Booking and set the Seat limit ---");
                                                
                                                }
            
                                                break;
                                    case 3:
                                                System.out.println("********************");
                                                System.out.println("  Business Studies  ");
                                                System.out.println("********************");
                                                System.out.println();
                                                
                                                if (sss2.getBusinessStudiesAmount() != 0) {
                                                    System.out.println("Available seats               : " + sss2.getBusinessStudiesAmount());
                                            
                                                    System.out.print(" Enter the number of seats  : ");
                                                        int an5 = sc.nextInt();
                                                        if(sss2.vacatingSeat (an5))
                                                        {
                                                            System.out.println("----- Seat Vacating Successfull -----");
                                                            System.out.println("Remaining seats after Vacated  : "+ sss2.getBusinessStudiesAmount());
                                                            frwd.writeInFile(an5 + " Seat Vacate in Business Studies " );
                                                        }
                                                        else
                                                        {
                                                            System.out.println("----- Seat Vacating Failed -----");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        System.out.println("--- Please go to Seat Booking and set the Seat limit ---");
                                                    
                                                    }
                
                                                    break;  
                                        case 4:
                                                    System.out.println("*********************");
                                                    System.out.println("Going Back...........");
                                                    System.out.println("*********************");
                                                    System.out.println();
                                                    repeat7 = false;
                                                    break;
                                       default:
				
                                                    System.out.println("######################");
                                                    System.out.println("Invalid Selection.....");
                                                    System.out.println("######################");
                                                    System.out.println();
                                                    repeat7 = false;
                                                    break;
                                    }
                               
                                    
                                }
								
								break;
						
                            case 3:
							
								System.out.println("*************************************");
								System.out.println("You Have Selected Seat Booking & Vacating History");
								System.out.println("*************************************");
								System.out.println();
								
								frwd.readFromFile();
								
								break;	
							case 4:
								
								System.out.println("*********************");
								System.out.println("Going Back...........");
								System.out.println("*********************");
								System.out.println();
								repeat4 = false;
								break;
								
							default:
								
								System.out.println("*********************");
								System.out.println("Invalid Option.......");
								System.out.println("*********************");
								System.out.println();
								
								break;
						     }
					      }
					
					     break;
			   case 5:
                            System.out.println("##################################");
                            System.out.println("You Have Selected College Information");
                            System.out.println("##################################");
                            System.out.println();
                            
                            cc.showDetails();
                            
                            break;
			   case 6:
					
                                System.out.println("###################################");
                                System.out.println("Thank You for Using Our Application");
                                System.out.println("###################################");
                                System.out.println();
                                
                                repeat = false;
                                
                                break;
			  default:
				
                                System.out.println("######################");
                                System.out.println("Invalid Selection.....");
                                System.out.println("######################");
                                System.out.println();
                                repeat = false;
                                break;
			}
		}		
	}
}