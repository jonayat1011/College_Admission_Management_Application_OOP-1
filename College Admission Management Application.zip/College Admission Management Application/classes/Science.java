package classes;

import java.lang.*;

public class Science extends Student
{
	private int scienceSeatAmount;
	private double markInPhysics;
	private double markInChemisty;
	
	public Science()
	{

	}
	public Science(String studentID, Account account, int roll , String groupName , String optionalSubject , double markInPhysics,double markInChemisty)
	{
		super( studentID,account,roll,groupName,optionalSubject);
		this.markInChemisty=markInChemisty;
		this.markInPhysics = markInPhysics;
	}
	
	public void setMarkInPhysics(double markInPhysics)
	{
		this.markInPhysics = markInPhysics;
	}
	public void setMarkInChemistry (double markInChemistry)
	{
	     this.markInChemisty=markInChemistry;
	}
	public void setScienceSeatAmount (int scienceSeatAmount)
	{
       this.scienceSeatAmount = scienceSeatAmount;
	}
    public double getMarkInPhysics () 
	{
		return markInPhysics;
	}	
	public double getMarkInChemistry () 
	{
		return markInChemisty;
	}
	public int getScienceSeatAmount () 
	{
		return scienceSeatAmount;
	}

	public  boolean fillingSeat (int amount)
	{ 
		if(amount>0 && amount<=scienceSeatAmount){
		
	
		scienceSeatAmount=scienceSeatAmount-amount;

        return true;
     	}
		return false;
	}
    public boolean vacatingSeat (int amount)
	{   
		if((amount>0)){
			
			scienceSeatAmount=scienceSeatAmount+amount;
			return true;
		}
		return false;
	}
	public void showDetails()
	{   System.out.println("                       ");
	    System.out.println("-----------------------");
		System.out.println("Student ID           : " + this.getStudentID());
		this.getAccount().showDetails();
		System.out.println("Roll                 : " + this.getRoll());
		System.out.println("Group Name           : " + this.getGroupName());
	    System.out.println("Optional Subject     : " + this.getOptionalSubject());
		System.out.println("Mark In Physics      : " + markInPhysics );
	    System.out.println("Mark In Chemisty     : " + markInChemisty );

	}
}
	