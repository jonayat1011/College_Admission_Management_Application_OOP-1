package classes;

import java.lang.*;
import interfaces.*;

public class College implements EmployeeOperations , AccountOperations,StudentOperations
{
	private String name;
	private String branchName;
	Account accounts[] = new Account [2000];
	Student students[] = new Student [1500];
	Employee employees[] = new Employee [100];
	
	public College(){}
	public College(String name, String branchName)
	{
		this.name = name;
		this.branchName = branchName;
	}
	
	public void setName(String name){this.name = name;}
	public void setBranchName(String branchName){this.branchName = branchName;}
	
	public String getName(){return name;}
	public String getBranchName(){return branchName;}

	public boolean insertAccount(Account a)
	{
		for(int i=0; i<accounts.length; i++)
		{
			if(accounts[i] == null)
			{
				accounts[i] = a;
				return true;
			}
		}
		return false;
	}
	
	public boolean removeAccount(Account a)
	{
		for(int i=0; i<accounts.length; i++)
		{
			if(accounts[i] == a)
			{
				accounts[i] = null;
				return true;
			}
		}
		return false;
	}
	
	public Account searchAccount(String nid)
	{
		for(int i=0; i<accounts.length; i++)
		{
			if(accounts[i] != null)
			{
				if(accounts[i].getNid().equals(nid))
				{
					return accounts[i];
				}
			}
		}
		return null;
	}
	
	public void showAllAccounts()
	{
		for(int i=0; i<accounts.length; i++)
		{
			if(accounts[i] != null)
			{
				accounts[i].showDetails();
			}
		}
	}
	
	
	public boolean insertStudent(Student s)
	{
		for(int i=0; i<students.length; i++)
		{
			if(students[i] == null)
			{
				students[i] = s;
				return true;
			}
		}
		return false;
	}
	
	public boolean removeStudent(Student s)
	{
		for(int i=0; i<students.length; i++)
		{
			if(students[i] == s)
			{
				students[i] = null;
				return true;
			}
		}
		return false;
	}
	
	public Student searchStudent(String studentID)
	{
		for(int i=0; i<students.length; i++)
		{
			if(students[i] != null)
			{
				if(students[i].getStudentID().equals(studentID))
				{
					return students[i];
				}
			}
		}
		return null;
	}
	
	public void showAllStudents()
	{
		for(int i=0; i<students.length; i++)
		{
			if(students[i] != null)
			{
				students[i].showDetails();
			}
		}
	}
	
	public boolean insertEmployee(Employee e)
	{
		for(int i=0; i<employees.length; i++)
		{
			if(employees[i] == null)
			{
				employees[i] = e;
				return true;
			}
		}
		return false;
	}
	
	public boolean removeEmployee(Employee e)
	{
		for(int i=0; i<employees.length; i++)
		{
			if(employees[i] == e)
			{
				employees[i] = null;
				return true;
			}
		}
		return false;
	}
	
	public Employee searchEmployee(String empId )
	{
		for(int i=0; i<employees.length; i++)
		{
			if(employees[i] != null)
			{
				if(employees[i].getEmpId().equals(empId))
				{
					return employees[i];
				}
			}
		}
		return null;
	}
	
	public void showAllEmployees()
	{
		for(int i=0; i<employees.length; i++)
		{
			if(employees[i] != null)
			{
				employees[i].showDetails();
			}
		}
	}
	
	public void showDetails()
	{   System.out.println("//////////////////////////////////");
	    System.out.println("                       ");
		System.out.println("College Name         : " + name);
		System.out.println("College Branch       : " + branchName);
		System.out.println("                       ");
		System.out.println("//////////////////////////////////");
		System.out.println("######## List of Accounts #######");
		this.showAllAccounts();
		System.out.println("//////////////////////////////////");
		System.out.println();
		System.out.println("######## List of Employees ######");
		this.showAllEmployees();
		System.out.println("//////////////////////////////////");
		System.out.println();
		System.out.println("######## List of Students #######");
		this.showAllStudents();
		System.out.println("//////////////////////////////////");
		
	}	
}