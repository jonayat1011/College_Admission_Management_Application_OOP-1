package classes;

import java.lang.*;
public class Humanities extends Student

{

	public int humanitiesSeatAmount; 
    public double markInLogic; 
    public double markInEconomics;
	public Humanities()
	{

	}
	public Humanities(String studentID, Account account, int roll,String groupName,String optionalSubject, double markInLogic,double markInEconomics)
	{
		super( studentID,account,roll,groupName,optionalSubject);
		this.markInLogic = markInLogic;
		this.markInEconomics = markInEconomics;
	}
	public void setMarkInLogic (double markInLogic ) 
	{
		this.markInLogic = markInLogic;
	}
    public double getMarkInLogic ()
	{
     return	markInLogic;
	}	 
    public void setMarkInEconomics(double markInEconomics) 
	{
		this.markInEconomics = markInEconomics;
	}
    public double getMarkInEconomics () 
	{ 
	return markInEconomics;
	}
	public void setHumanitiesSeatAmount (int humanitiesSeatAmount)
	{
		this.humanitiesSeatAmount = humanitiesSeatAmount;
	}
    public int getHumanitiesSeatAmount () 
	{
		return humanitiesSeatAmount;
	}
	public  boolean fillingSeat (int amount)
	{ 
		if(amount>0 && amount<=humanitiesSeatAmount){
		
	
			humanitiesSeatAmount=humanitiesSeatAmount-amount;

        return true;
     	}
		return false;
	}
    public boolean vacatingSeat (int amount)
	{   
		if((amount>0)){
			
			humanitiesSeatAmount=humanitiesSeatAmount+amount;
			return true;
		}
		return false;
	}
	public void showDetails()
	{   System.out.println("                       ");
	    System.out.println("-----------------------");
		System.out.println("Student ID           : " + this.getStudentID());
		this.getAccount().showDetails();
		System.out.println("Roll                 : " + this.getRoll());
		System.out.println("Group Name           : " + this.getGroupName());
	    System.out.println("Optional Subject     : " + this.getOptionalSubject());
		System.out.println("Mark In Logic        : " + markInLogic );
	    System.out.println("Mark In Economics    : " + markInEconomics );
	}
}