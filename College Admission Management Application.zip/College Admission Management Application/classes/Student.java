package classes;

import java.lang.*;
import interfaces.*;

public abstract class Student implements SeatOperations
{	
    private Account account;
	private String studentID;
    private int roll;
    private String groupName ;
    private String optionalSubject;
	
    
	
	public Student(){ }
	public Student(String studentID, Account account, int roll , String groupName ,String optionalSubject  )
	{
		this.studentID = studentID;
		this.account= account;
		this.roll = roll;
        this.groupName = groupName;
        this.optionalSubject= optionalSubject;
	}
    public void setAccount(Account account){	this.account= account;}
    public void setStudentID(String studentID){ this.studentID = studentID; }
    public void setRoll(int roll){	this.roll = roll;	}
    public void setGroupName(String groupName){	   this.groupName = groupName;}
    public void setOptionalSubject(String optionalSubject){	this.optionalSubject= optionalSubject;}
	
    public Account getAccount(){	return account;}
    public String getStudentID(){	return studentID;}
    public int getRoll (){	return roll;}
    public String getGroupName(){	return groupName;}
    public String getOptionalSubject(){	return optionalSubject;}


    public abstract boolean fillingSeat (int amount);

    public abstract boolean vacatingSeat (int amount);

	
	public abstract void showDetails();
	
	
}