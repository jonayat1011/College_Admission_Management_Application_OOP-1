package classes;
import java.lang.*;
public class BusinessStudies extends Student
{
	public int businessStudiesAmount; 
    public double markInAccounting; 
    public double markInBusinessORG; 

	public BusinessStudies()
	{

	}
	public BusinessStudies(String studentID, Account account, int roll,String groupName,String optionalSubject, double markInAccounting,double markInBusinessORG)
	{
		super( studentID,account,roll,groupName,optionalSubject);
		this.markInAccounting=markInAccounting;
		this.markInBusinessORG = markInBusinessORG;
	}

    public void setMarkInAccounting (double markInAccounting)
	{ this.markInAccounting = markInAccounting;
	}	
    public double getMarkInAccounting ()
	{ 
     return	markInAccounting;
	}
    public void setMarkInBusinessORG (double markInBusinessORG) 
	{
		this.markInBusinessORG = markInBusinessORG;
	}
    public double getMarkInBusinessORG () 
	{
		return markInBusinessORG;
	}
    public void setBusinessStudiesAmount (int businessStudiesAmount)
	{
		this.businessStudiesAmount = businessStudiesAmount;
	}
    public int getBusinessStudiesAmount () 
	{
		return businessStudiesAmount;
	}

    public  boolean fillingSeat (int amount)
	{ 
		if(amount>0 && amount<=businessStudiesAmount){
		
	
			businessStudiesAmount=businessStudiesAmount-amount;

        return true;
     	}
		return false;
	}
    public boolean vacatingSeat (int amount)
	{   
		if((amount>0)){
			
			businessStudiesAmount=businessStudiesAmount+amount;
			return true;
		}
		return false;
	}
	public void showDetails()
	{   System.out.println("                       ");
		System.out.println("-----------------------");
		System.out.println("Student ID           : " + this.getStudentID());
		this.getAccount().showDetails();
		System.out.println("Roll                 : " + this.getRoll());
		System.out.println("Group Name           : " + this.getGroupName());
	    System.out.println("Optional Subject     : " + this.getOptionalSubject());
		System.out.println("Mark In Accounting   : " + markInAccounting );
	    System.out.println("Mark In BusinessORG  : " + markInBusinessORG );
	



		
	}
}
	