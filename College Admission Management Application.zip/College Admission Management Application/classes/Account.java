package classes;

import java.lang.*;
public class Account
{
	private String name;
	private String nid;
	private String gender;
	private String phnNumber;
	private String admissionDate;

	public Account() {}
    public Account(String name,String nid,String gender ,String phnNumber,String admissionDate)
	{
		this.name = name;
		this.nid = nid;
		this.gender = gender;
		this.phnNumber = phnNumber;
		this.admissionDate = admissionDate;

	}
	public void setName(String name)
	{
		this.name = name;
	}
	public void setNid(String nid)
	{
		this.nid = nid;
	}
	public void setGender(String gender)
	{
		this.gender = gender;
	}
	public void setPhnNumber(String phnNumber)
	{
	this.phnNumber = phnNumber;
	}
	public void setAdmissionDate(String admissionDate)
	{
		this.admissionDate = admissionDate;
	}
	public String getName()
	{
		return name;
	}
	public String getNid()
	{
		return nid;
	}
	public String getGender()
	{
		return gender;
	}
	public String getPhnNumber()
	{
	return phnNumber;
	}
	public String getAdmissionDate()
	{
	return admissionDate;
	}
	public void showDetails()
	{   System.out.println("                       ");
		System.out.println("Name                 : " + name);
		System.out.println("NID                  : " + nid);
		System.out.println("Gender               : " + gender);
	    System.out.println("Phn Number           : " + phnNumber);
		System.out.println("Admission Date       : " + admissionDate);
		System.out.println("                       ");	
	}


}