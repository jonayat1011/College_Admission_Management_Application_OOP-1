package classes;
import java.lang.*;

public class Employee
{
	private Account account;
	private String empId;
	private double salary;
    
	public Employee ()
	{

	}
	public Employee (String empId , Account account, double salary)
	{
		this.empId = empId;
		this.account= account;
		this.salary = salary;
	}
	public void setEmpId(String empId)
	{this.empId = empId;}
	
	public void setSalary(double salary)
	{this.salary = salary;}
	public void setAccount(Account account)
	{	this.account= account;}

	public String getEmpId()
	{return empId;} 

	public double getSalary()
	{return salary;} 
	public Account getAccount()
	{	return account;}

	public void showDetails()
	{   System.out.println("                       ");
	    System.out.println("-----------------------");
		System.out.println("Employee ID          : " + empId);
		this.getAccount().showDetails();
		System.out.println("Employee Salary      : " + salary);
		System.out.println();
	}
}