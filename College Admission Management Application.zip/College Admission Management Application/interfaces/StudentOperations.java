package interfaces;
import java.lang.*;
import classes.*;

public interface StudentOperations
{
	boolean insertStudent(Student s);
	boolean removeStudent(Student s);
	Student searchStudent(String studentID);
	void showAllStudents();

}