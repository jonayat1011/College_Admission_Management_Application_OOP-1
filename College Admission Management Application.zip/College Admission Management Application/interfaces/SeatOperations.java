package interfaces;
import java.lang.*;
import classes.*;
public interface SeatOperations
{
    boolean fillingSeat (int amount);
     boolean vacatingSeat (int amount);
}